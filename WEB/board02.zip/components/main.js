export default {
    template : `
    <div>
        <h3>게시판을 불러와주세요</h3>
    </div>`
}