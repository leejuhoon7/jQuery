export default {
    template : 
    `<div>
    <h3>게시판 부르기</h3>
</div>
    `
}